"""Typed errors for ORVYN's tool infrastructure."""


class ToolErrorBase(Exception):
    """Base exception for ORVYN's tool infrastructure."""


class ToolNotFoundError(ToolErrorBase):
    """Requested tool is not registered."""


class ToolAlreadyRegisteredError(ToolErrorBase):
    """A tool name is already registered."""


class ToolNameValidationError(ToolErrorBase):
    """A tool uses an invalid or unsafe name."""


class ToolDisabledError(ToolErrorBase):
    """A registered tool exists but is disabled."""


class ToolValidationError(ToolErrorBase):
    """Tool arguments failed validation."""


class ToolPermissionDeniedError(ToolErrorBase):
    """Execution lacks a required permission."""


class ToolApprovalRequiredError(ToolErrorBase):
    """Explicit user approval is required before execution."""


class ToolApprovalNotFoundError(ToolErrorBase):
    """An approval request could not be found."""


class ToolApprovalDeniedError(ToolErrorBase):
    """An approval request was denied."""


class ToolApprovalExpiredError(ToolErrorBase):
    """An approval request has expired."""


class ToolApprovalConsumedError(ToolErrorBase):
    """A one-time approval has already been used."""


class ToolApprovalMismatchError(ToolErrorBase):
    """Approval does not match the user, tool, or arguments."""


class ToolPolicyConfigurationError(ToolErrorBase):
    """Tool metadata violates ORVYN's minimum safety policy."""


class ToolSelectionError(ToolErrorBase):
    """Base error for model-generated tool selection."""


class ToolSelectionParseError(ToolSelectionError):
    """Model output does not match the strict JSON contract."""


class ToolSelectionRejectedError(ToolSelectionError):
    """Proposed tool call failed registry or argument validation."""


class ToolExecutionError(ToolErrorBase):
    """An approved tool failed during execution."""