
from pydantic import BaseModel

from app.schemas.tool import ToolDefinition


class RegisteredToolInfo(BaseModel):
    """Safe metadata for one registered tool."""

    definition: ToolDefinition
    enabled: bool


class ToolRegistrySnapshot(BaseModel):
    """Read-only snapshot of registered tool metadata."""

    tools: list[RegisteredToolInfo]
    total: int
    enabled: int
    disabled: int
