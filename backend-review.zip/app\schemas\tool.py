
from __future__ import annotations

from typing import Any
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from app.tools.enums import (
    ToolExecutionStatus,
    ToolPermission,
    ToolRiskLevel,
)


class ToolInputModel(BaseModel):
    """Strict base model for untrusted tool arguments."""

    model_config = ConfigDict(extra="forbid")


class ToolDefinition(BaseModel):
    """Public machine-readable description of a tool."""

    name: str = Field(min_length=1, max_length=100)
    description: str = Field(min_length=1, max_length=1000)
    version: str = Field(default="1.0.0", min_length=1, max_length=50)
    risk_level: ToolRiskLevel = ToolRiskLevel.LOW
    permissions: list[ToolPermission] = Field(default_factory=list)
    requires_approval: bool = False
    input_schema: dict[str, Any] = Field(default_factory=dict)


class ToolExecutionContext(BaseModel):
    """Trusted context created by ORVYN, never by an LLM."""

    model_config = ConfigDict(extra="forbid")

    user_id: UUID
    conversation_id: UUID | None = None
    message_id: UUID | None = None
    execution_id: UUID
    granted_permissions: list[ToolPermission] = Field(default_factory=list)
    approved: bool = False


class ToolCallRequest(BaseModel):
    """Untrusted requested tool invocation."""

    model_config = ConfigDict(extra="forbid")

    tool_name: str = Field(min_length=1, max_length=100)
    arguments: dict[str, Any] = Field(default_factory=dict)


class ToolError(BaseModel):
    """Safe error representation for API consumers."""

    code: str = Field(min_length=1, max_length=100)
    message: str = Field(min_length=1, max_length=1000)
    retryable: bool = False


class ToolExecutionResult(BaseModel):
    """Standard result returned by the execution boundary."""

    execution_id: UUID
    tool_name: str
    status: ToolExecutionStatus
    output: Any | None = None
    error: ToolError | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
