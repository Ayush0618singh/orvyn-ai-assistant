
from __future__ import annotations


class ChunkingService:
    """Split extracted text into overlapping, searchable chunks."""

    def __init__(
        self,
        *,
        chunk_size: int = 1000,
        overlap: int = 150,
    ) -> None:
        if chunk_size < 1:
            raise ValueError("chunk_size must be positive.")

        if overlap < 0:
            raise ValueError("overlap cannot be negative.")

        if overlap >= chunk_size:
            raise ValueError("overlap must be smaller than chunk_size.")

        self.chunk_size = chunk_size
        self.overlap = overlap

    def chunk_text(self, text: str) -> list[str]:
        if not isinstance(text, str):
            raise TypeError("Document text must be a string.")

        text = text.strip()
        if not text:
            return []

        # Normalize line endings and excessive blank lines.
        text = text.replace("\r\n", "\n").replace("\r", "\n")

        normalized_lines = []
        for line in text.split("\n"):
            normalized_lines.append(" ".join(line.split()))

        text = "\n".join(normalized_lines)
        text = text.strip()

        if not text:
            return []

        chunks: list[str] = []
        start = 0
        text_length = len(text)

        while start < text_length:
            end = min(start + self.chunk_size, text_length)

            # Prefer a natural boundary without producing tiny chunks.
            if end < text_length:
                minimum_boundary = start + int(self.chunk_size * 0.65)
                candidates = [
                    text.rfind("\n\n", minimum_boundary, end),
                    text.rfind("\n", minimum_boundary, end),
                    text.rfind(". ", minimum_boundary, end),
                    text.rfind(" ", minimum_boundary, end),
                ]
                boundary = max(candidates)

                if boundary >= minimum_boundary:
                    # Keep punctuation with the preceding sentence.
                    end = boundary + (
                        1 if text[boundary:boundary + 2] == ". " else 0
                    )

            chunk = text[start:end].strip()
            if chunk:
                chunks.append(chunk)

            if end >= text_length:
                break

            next_start = max(0, end - self.overlap)

            # Ensure progress even when whitespace/boundaries are unusual.
            if next_start <= start:
                next_start = end

            start = next_start

        return chunks


chunking_service = ChunkingService()
