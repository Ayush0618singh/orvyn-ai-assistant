
from __future__ import annotations

from pathlib import Path


class UnsafeStoragePathError(ValueError):
    """Raised when a storage path escapes its permitted root."""


def resolve_storage_root(root: str | Path) -> Path:
    """Resolve and validate the configured attachment storage root."""
    path = Path(root).expanduser().resolve(strict=False)

    if not path.is_absolute():
        raise UnsafeStoragePathError(
            "Storage root must be an absolute path."
        )

    return path


def resolve_user_storage_dir(
    root: str | Path,
    user_id: str,
) -> Path:
    """Return a user-specific directory without permitting traversal."""
    if not isinstance(user_id, str) or not user_id.strip():
        raise UnsafeStoragePathError("Invalid user identifier.")

    if user_id in {".", ".."} or "/" in user_id or "\\" in user_id:
        raise UnsafeStoragePathError("Invalid user identifier.")

    storage_root = resolve_storage_root(root)
    user_dir = (storage_root / user_id).resolve(strict=False)

    if user_dir.parent != storage_root:
        raise UnsafeStoragePathError(
            "User storage directory escapes the storage root."
        )

    return user_dir


def resolve_storage_file(
    root: str | Path,
    user_id: str,
    stored_name: str,
) -> Path:
    """Resolve a stored filename and enforce user-directory containment."""
    if not isinstance(stored_name, str) or not stored_name.strip():
        raise UnsafeStoragePathError("Invalid stored filename.")

    filename = Path(stored_name)

    if (
        filename.name != stored_name
        or stored_name in {".", ".."}
        or "/" in stored_name
        or "\\" in stored_name
    ):
        raise UnsafeStoragePathError("Invalid stored filename.")

    user_dir = resolve_user_storage_dir(root, user_id)
    file_path = (user_dir / stored_name).resolve(strict=False)

    if file_path.parent != user_dir:
        raise UnsafeStoragePathError(
            "Attachment path escapes the user storage directory."
        )

    return file_path


def resolve_existing_storage_path(
    root: str | Path,
    user_id: str,
    stored_name: str,
    recorded_path: str | Path,
) -> Path:
    """Validate a database-recorded path against the expected stored file."""
    expected = resolve_storage_file(root, user_id, stored_name)
    recorded = Path(recorded_path).expanduser().resolve(strict=False)

    if recorded != expected:
        raise UnsafeStoragePathError(
            "Recorded attachment path does not match its expected location."
        )

    return expected
